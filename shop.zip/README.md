# Ecommerce-flask

Ecommerce-flask

Step 1:
    
     Create the virtual Environment (python 3.7)

Step 2:

     Activate the virtual environment

Step 3:

     pip install -r requirements.txt

Step 4:

     Update the Environment Variable

     export FLASK_APP=run    (for ubuntu)

     perform below steps inside the shop directory in terminal or cmd

Step 5:

     flask db init    

Step 6:

     flask db migrate

Step 7:

     flask db upgrade

Step 8:
      
     flask run
     
     Your application running in the below url

     http://localhost:5000/ 
     
   
       



